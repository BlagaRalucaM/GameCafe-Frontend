import User from './user';

interface UsersResponse {
  users: User[];
}

export default UsersResponse;
